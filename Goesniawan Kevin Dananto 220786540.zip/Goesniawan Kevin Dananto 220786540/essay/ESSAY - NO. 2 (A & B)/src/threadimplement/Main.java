/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package threadimplement;

/**
 *
 * @author ACER
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int i = 0;
        while (i<10) {
            ImplementThreadRunnable[] firstThread = new ImplementThreadRunnable[10];
            ExtendThreadClass[] secondThread = new ExtendThreadClass[10];
        
            firstThread[i] = new ImplementThreadRunnable(String.valueOf(i+1));
            secondThread[i] = new ExtendThreadClass(String.valueOf(i+11));
            
            firstThread[i].start();
            secondThread[i].start();
            i++;
        }
    }
    
}
