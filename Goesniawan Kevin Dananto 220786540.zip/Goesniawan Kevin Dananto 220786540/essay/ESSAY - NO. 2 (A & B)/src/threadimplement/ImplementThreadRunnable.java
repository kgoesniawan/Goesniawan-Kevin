/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package threadimplement;

/**
 *
 * @author ACER
 */
public class ImplementThreadRunnable implements Runnable {
    private Thread newThread;
    private String threadLabel;
    
    public ImplementThreadRunnable(String threadLabel) {
        this.threadLabel = threadLabel;
    }
    
    @Override
    public void run() {
        funcA();
    }
    
    public void start() {
        if (newThread == null) {
            newThread = new Thread(this, threadLabel);
            newThread.start();
        }
    }
    
    private void funcA() {
        System.out.print(threadLabel + " thread ");
        System.out.println(4 / 2 + 10);
    }
}
