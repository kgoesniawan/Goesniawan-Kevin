/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package threadimplement;

/**
 *
 * @author ACER
 */
public class ExtendThreadClass extends Thread {
    private Thread newThread;
    private String threadLabel;
    
    public ExtendThreadClass(String threadLabel) {
        this.threadLabel = threadLabel;
    }
    
    public void run() {
        funcB();
    }
    
    public void start() {
        if (newThread == null) {
            newThread = new Thread(this, threadLabel);
            newThread.start();
        }
    }
    
    private void funcB() {
        System.out.print(threadLabel + " thread ");
        System.out.println(3+5-1);
    }
}
