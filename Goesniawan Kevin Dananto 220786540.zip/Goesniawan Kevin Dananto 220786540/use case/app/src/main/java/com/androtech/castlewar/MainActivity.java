package com.androtech.castlewar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageView youWin1;
    private ImageView youWin2;
    private Button btnBattle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        youWin1 = findViewById(R.id.youWin1);
        youWin2 = findViewById(R.id.youWin2);
        btnBattle = findViewById(R.id.btnBattle);
        btnBattle.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnBattle) {
            battle();
        }
    }

    private void battle() {
        int firstTroopsQty = 100000;
        int secondTroopsQty = 100000;

        int firstTroopsType = 1;
        int secondTroopsType = 2;

        double firstTroopBoost = 0.4 * 5;
        double secondTroopBoost = 0.4 * 5;

        double firstTroopsPower = firstTroopsQty + firstTroopBoost * firstTroopsQty;
        double secondTroopsPower = secondTroopsQty + secondTroopBoost * secondTroopsQty;

        double firstTroopsKill = kill(firstTroopsType, secondTroopsType, firstTroopsPower);
        double secondTroopsKill = kill(secondTroopsType, firstTroopsType, secondTroopsPower);

        double firstSurviveQty = firstTroopsQty - secondTroopsKill;
        double secondSurviveQty = secondTroopsQty - firstTroopsKill;

        if (firstSurviveQty > secondSurviveQty) {
            youWin1.setVisibility(View.VISIBLE);
        }
        else if (firstSurviveQty < secondSurviveQty) {
            youWin2.setVisibility(View.VISIBLE);
        }

    }

    private double kill(int firstTroopsType, int secondTroopsType, double troopsPower) {
        double killNumber = 0;
        if(firstTroopsType == 0) {
            if (secondTroopsType == 0) killNumber = troopsPower;
            else if (secondTroopsType == 1) killNumber = 0.1 * troopsPower;
            else killNumber = 0.4 * troopsPower;
        }
        else if(firstTroopsType == 1) {
            if (secondTroopsType == 0) killNumber = 0.4 * troopsPower;
            else if (secondTroopsType == 1) killNumber = troopsPower;
            else killNumber = 0.1 * troopsPower;
        }
        else {
            if (secondTroopsType == 0) killNumber = 0.1 * troopsPower;
            else if (secondTroopsType == 1) killNumber = 0.4 * troopsPower;
            else killNumber = troopsPower;
        }
        return killNumber;
    }
}